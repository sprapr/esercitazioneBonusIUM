package com.example.esercitazionebonus;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.esercitazionebonus.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {


    private ActivityMainBinding bind;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        bind = DataBindingUtil.setContentView(this, R.layout.activity_main);

        bind.loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                bind.attrPassword.setText("fhdjklhafjklsahfjdksh fklsa");

            }
        });
    }

    public boolean login () {
        if (bind.attrUsername.getText().toString().equals("admin") && bind.attrPassword.getText().toString().equals("admin")){
            return true;
        }
    return false;
    }
}