package com.example.esercitazionebonus;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import com.example.esercitazionebonus.databinding.ActivityMainBinding;
import com.example.esercitazionebonus.databinding.ActivityRegistrazioneBinding;

public class RegistrazioneActivity extends AppCompatActivity {
    private ActivityRegistrazioneBinding bind;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        bind = DataBindingUtil.setContentView(this, R.layout.activity_registrazione);


    }
}
